from django.contrib import admin
from .models import Information,StudentGrade,Teacher

# Register your models here.
admin.site.register(Information)
admin.site.register(StudentGrade)
admin.site.register(Teacher)
