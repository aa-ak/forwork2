from django.urls import path
from . import views
app_name='polls'
urlpatterns = [
    path('hello/', views.hello, name='hello'),
    path('student_info/', views.student_info, name='student_info'),
    path('student_grade_info/', views.student_grade_info, name='student_grade_info'),
    path('delete_student_grade/<int:student_grade_id>/',views.delete_student_grade,name='delete_student_grade'),
    path('delete_student_info/<int:student_info_id>/',views.delete_student_info,name='delete_student_info'),
]