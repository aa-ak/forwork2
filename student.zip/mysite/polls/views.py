from django.shortcuts import render,get_object_or_404, redirect
from .models import Information, StudentGrade

# Create your views here.
def hello(request):
    return render(request,'hello.html')
def student_info(request):
    students = Information.objects.all()
    return render(request, 'student_info.html', {'students': students})
def student_grade_info(request):
    student_grades = StudentGrade.objects.all()
    return render(request, 'student_grade_info.html', {'student_grades':student_grades})

def delete_student_grade(request,student_grade_id):
    student_grade = get_object_or_404(StudentGrade,pk=student_grade_id)
    student_grade.delete_student_grade()
    return redirect('polls:student_grade_info')

def delete_student_info(request,student_info_id):
    student_info = get_object_or_404(Information,pk=student_info_id)
    student_info.delete_student_info()
    return redirect('polls:student_info')

def edit_student_info(request,student_info_id):
    student_info = get_object_or_404(Information,pk=student_info_id)
    if request.method == 'POST':
        new_name = request.POST['new_name']
        new_sex = request.POST['new_sex']
        new_college = request.POST['new_college']
        new_class_name = request.POST['new_class']

#         更新学生信息
        student_info.name = new_name
        student_info.sex = new_sex
        student_info.college = new_college
        student_info.class_name = new_class_name
        student_info.save()

        return redirect('polls:student_info')



