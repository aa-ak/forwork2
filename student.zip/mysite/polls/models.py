from django.db import models
# Create your models here.
class Information(models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=64, null=False,unique=True,verbose_name='姓名')
    sex = models.CharField(max_length=12,null=True,verbose_name='性别')
    college = models.CharField(max_length=12,verbose_name='课程')
    class_name = models.CharField(max_length=12,verbose_name='班级')

    def delete_student_info(self):
        self.delete()
class StudentGrade(models.Model):
    id = models.AutoField(primary_key=True)
    course = models.CharField(max_length=12,verbose_name="课程")
    score = models.IntegerField(verbose_name="分数")
    information = models.ForeignKey(to=Information ,related_name="StudentGrade", on_delete=models.CASCADE)

    def delete_student_grade(self):
        self.delete()
class Teacher(models.Model):
    id = models.AutoField(primary_key=True)
    studentGrade = models.ManyToManyField(to="StudentGrade")


